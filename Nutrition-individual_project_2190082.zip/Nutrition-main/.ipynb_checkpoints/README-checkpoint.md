# Nutrition

This repsoitory can be found at:
https://github.com/msw64/Nutrition

This notebook uses a publicly available csv file from Kaggle: https://www.kaggle.com/

This notebook can also be used with any csv file that is fomatted in the same way as this file, which could be useful if anyone has collected their own data regarding nutritrient content from different foods. However, this noteboook will utiilise the nutrition.csv provided.

To run the code:
1) Download the contents of this repository into a single directory
2) Open the notebook file and proceed to run the code using the csv file provided.
